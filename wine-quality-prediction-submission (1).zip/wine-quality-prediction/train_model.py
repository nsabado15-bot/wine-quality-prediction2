"""
Wine Quality Prediction System
Downloads the UCI Red Wine Quality dataset, performs basic checks,
trains a binary Random Forest classifier, evaluates it, and saves artifacts.
"""

from pathlib import Path
import urllib.request
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

DATA_URL = (
    "https://archive.ics.uci.edu/ml/machine-learning-databases/"
    "wine-quality/winequality-red.csv"
)
DATA_PATH = Path("wine_quality.csv")
MODEL_PATH = Path("wine_model.pkl")
EVALUATION_PATH = Path("model_evaluation.txt")

def main():
    print("Downloading UCI Red Wine Quality dataset...")
    df = pd.read_csv(DATA_URL, sep=";")
    df.to_csv(DATA_PATH, index=False)

    print("\nDataset preview:")
    print(df.head())
    print("\nDataset shape:", df.shape)
    print("\nMissing values by column:\n", df.isna().sum())
    print("\nDuplicate rows:", int(df.duplicated().sum()))
    print("\nOriginal quality distribution:\n", df["quality"].value_counts().sort_index())

    # Remove exact duplicate records before training.
    df = df.drop_duplicates().copy()

    # Binary target: quality >= 6 is GOOD QUALITY; otherwise NEEDS IMPROVEMENT.
    y = (df["quality"] >= 6).astype(int)

    # IMPORTANT: exclude the original quality column to prevent target leakage.
    X = df.drop(columns=["quality"])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    model = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("classifier", RandomForestClassifier(
            n_estimators=150,
            random_state=42,
            class_weight="balanced"
        ))
    ])

    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)
    precision = precision_score(y_test, predictions, zero_division=0)
    recall = recall_score(y_test, predictions, zero_division=0)
    f1 = f1_score(y_test, predictions, zero_division=0)
    cm = confusion_matrix(y_test, predictions)

    report = f"""WINE QUALITY MODEL EVALUATION
Dataset: UCI Red Wine Quality
Target rule: quality >= 6 = GOOD QUALITY; quality < 6 = NEEDS IMPROVEMENT
Test size: 20%
Random state: 42

Accuracy: {accuracy:.3f}
Precision (weighted positive class): {precision:.3f}
Recall (weighted positive class): {recall:.3f}
F1-score (weighted positive class): {f1:.3f}

Confusion Matrix:
{cm}

Classification Report:
{classification_report(y_test, predictions, target_names=["Needs Improvement", "Good Quality"], zero_division=0)}
"""
    print(report)
    EVALUATION_PATH.write_text(report, encoding="utf-8")

    joblib.dump(model, MODEL_PATH)
    print(f"\nSaved model: {MODEL_PATH}")
    print(f"Saved dataset: {DATA_PATH}")
    print(f"Saved evaluation: {EVALUATION_PATH}")

if __name__ == "__main__":
    main()
