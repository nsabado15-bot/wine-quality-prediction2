# SAD Mini-Analysis and Reflection

## 1. Problem
Wine quality information is recorded through several chemical measurements. Reviewing samples manually may take time, and users may want a consistent way to estimate a quality category from those measurements. This project demonstrates a basic classification system.

## 2. User
The intended users are students, instructors, and people learning about data mining and introductory wine-quality analysis. It is not designed as a certified tool for commercial wine grading.

## 3. Inputs
The system accepts a CSV file containing 11 numeric predictor fields:
- fixed acidity
- volatile acidity
- citric acid
- residual sugar
- chlorides
- free sulfur dioxide
- total sulfur dioxide
- density
- pH
- sulphates
- alcohol

The original `quality` field may be present in the uploaded UCI file, but it is not used as a prediction feature.

## 4. Process
1. Download and load the UCI Red Wine Quality dataset.
2. Inspect the dataset, missing values, and duplicate records.
3. Remove duplicate rows for model training.
4. Convert the quality score into a binary target: score 6 or higher is GOOD QUALITY; below 6 is NEEDS IMPROVEMENT.
5. Split the data into training and testing sets.
6. Train a Random Forest classifier using a preprocessing pipeline.
7. Evaluate the model using accuracy, precision, recall, F1-score, confusion matrix, and classification report.
8. Save the trained model as `wine_model.pkl`.
9. In the Streamlit app, validate the uploaded CSV columns, make predictions, show the results, and allow CSV download.

## 5. Outputs
- Predicted category for each uploaded wine sample: GOOD QUALITY or NEEDS IMPROVEMENT.
- Summary counts of each predicted category.
- A results table and downloadable CSV file.
- Model evaluation metrics and confusion matrix.

## 6. Limitations
The dataset contains red wine samples and may not represent all wine types, regions, or production methods. The binary threshold simplifies the original quality score. Predictions can be wrong and depend on the quality and representativeness of the input data. The system is for learning purposes and is not a substitute for laboratory testing or expert assessment.

---

# Brief Reflection Answers

### 1. What did you learn from this activity?
I learned how to collect a dataset, prepare the data, train a machine-learning model, and evaluate its performance. I also learned how to connect a trained model to a simple Streamlit application.

### 2. What was the most challenging part?
The most challenging part was setting up the tools and making sure the dataset, trained model, and application worked together. I had to check errors and run the steps carefully.

### 3. Why is data cleaning important?
Data cleaning helps improve the quality of the information used for training. Checking missing values and duplicate records helps prevent avoidable problems in the model.

### 4. What does the model evaluation tell you?
The evaluation shows how often the model makes correct predictions and how well it identifies each category. The model achieved about 77.2% accuracy in my test run, so it performs reasonably but can still make incorrect predictions.

### 5. How can the system be improved?
The system could be improved by testing other algorithms, tuning model settings, using more varied wine data, and collecting more representative samples. The app could also include clearer explanations of prediction results.
