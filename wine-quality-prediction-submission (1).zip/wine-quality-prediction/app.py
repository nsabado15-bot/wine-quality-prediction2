import streamlit as st
import pandas as pd
import joblib
from pathlib import Path

st.set_page_config(page_title="Wine Quality Prediction", page_icon="🍷", layout="wide")

st.title("🍷 Wine Quality Prediction System")
st.write(
    "Upload a CSV file containing the 11 wine-chemistry predictor columns. "
    "The model predicts GOOD QUALITY or NEEDS IMPROVEMENT."
)

MODEL_FILE = Path("wine_model.pkl")
if not MODEL_FILE.exists():
    st.error("Model file not found. Run `python train_model.py` first to create wine_model.pkl.")
    st.stop()

model = joblib.load(MODEL_FILE)

required_columns = [
    "fixed acidity", "volatile acidity", "citric acid", "residual sugar",
    "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density",
    "pH", "sulphates", "alcohol"
]

with st.sidebar:
    st.header("About the model")
    st.write("Dataset: UCI Red Wine Quality")
    st.write("Target rule: quality ≥ 6 is GOOD QUALITY.")
    st.write("Target rule: quality < 6 is NEEDS IMPROVEMENT.")
    st.caption("Educational demonstration only; not a professional wine-lab assessment.")

st.subheader("1. Upload wine data")
uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])

st.caption("Tip: the original UCI dataset contains a `quality` column. The app ignores it and uses only the 11 predictor columns.")

if uploaded_file is not None:
    try:
        data = pd.read_csv(uploaded_file, sep=None, engine="python")
        missing = [col for col in required_columns if col not in data.columns]

        if missing:
            st.error("Missing required columns: " + ", ".join(missing))
            st.write("Required columns:", required_columns)
        else:
            X = data[required_columns].apply(pd.to_numeric, errors="coerce")
            invalid_rows = X.isna().any(axis=1).sum()

            if invalid_rows:
                st.warning(
                    f"{invalid_rows} row(s) contain missing or non-numeric predictor values. "
                    "The model's median imputer will handle missing values."
                )

            predictions = model.predict(X)
            results = data.copy()
            results["Predicted Quality Category"] = [
                "GOOD QUALITY" if value == 1 else "NEEDS IMPROVEMENT"
                for value in predictions
            ]

            good_count = int((predictions == 1).sum())
            needs_count = int((predictions == 0).sum())

            st.subheader("2. Prediction summary")
            c1, c2, c3 = st.columns(3)
            c1.metric("Total records", len(results))
            c2.metric("Good quality", good_count)
            c3.metric("Needs improvement", needs_count)

            st.subheader("3. Prediction results")
            st.dataframe(results, use_container_width=True)

            csv_data = results.to_csv(index=False).encode("utf-8")
            st.download_button(
                "Download prediction results",
                data=csv_data,
                file_name="wine_quality_predictions.csv",
                mime="text/csv"
            )
    except Exception as error:
        st.error(f"Could not read or process this file: {error}")
else:
    st.info("Upload a CSV file to see prediction results.")
    st.write("Expected columns:")
    st.code(", ".join(required_columns))
