# Submission Checklist

- [ ] SAD mini-analysis (problem, user, inputs, process, outputs, limitation) – see `SAD_and_Reflection.md`
- [ ] `train_model.py`
- [ ] `app.py`
- [ ] `requirements.txt`
- [ ] `README.md`
- [ ] Model evaluation results – see `model_evaluation.txt`
- [ ] Screenshot of the Streamlit dashboard
- [ ] Screenshot of actual prediction results
- [ ] GitHub repository URL
- [ ] Brief answers to reflection questions – see `SAD_and_Reflection.md`

## Screenshot evidence
After running the app and uploading a CSV:
1. Take one screenshot showing the Streamlit dashboard.
2. Take another screenshot showing the prediction summary and results table.
3. Save the real screenshots in this folder before submitting.

Do not submit a mock screenshot as proof that the app was successfully run.
