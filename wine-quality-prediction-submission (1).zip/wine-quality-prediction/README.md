# Wine Quality Prediction System

A student project that classifies red wine samples into two categories using a Random Forest model.

## Classification rule
- `quality >= 6` → `GOOD QUALITY`
- `quality < 6` → `NEEDS IMPROVEMENT`

The original `quality` column is used only to create the target label. It is excluded from model input features to prevent target leakage.

## Project files
- `train_model.py` – downloads the UCI dataset, checks data quality, trains/evaluates the model, and saves artifacts.
- `app.py` – Streamlit application for CSV upload, prediction display, and result download.
- `requirements.txt` – Python package dependencies.
- `SAD_and_Reflection.md` – SAD mini-analysis and reflection answers.
- `model_evaluation.txt` – sample evaluation from the student's completed Colab run.

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Train the model and download the dataset:

   ```bash
   python train_model.py
   ```

5. Start the app:

   ```bash
   streamlit run app.py
   ```

6. Open the local URL shown in the terminal (usually `http://localhost:8501`).

## Deploy with Streamlit Community Cloud
1. Push `app.py`, `requirements.txt`, `README.md`, and the generated `wine_model.pkl` to a public GitHub repository.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Choose **Create app**, select the repository and branch, and set the main file path to `app.py`.
4. Deploy. The app needs `wine_model.pkl` in the repository root.
5. Keep the GitHub repository URL and deployed app URL for submission.

## Expected CSV format
The uploaded file must contain these 11 numeric columns:
`fixed acidity`, `volatile acidity`, `citric acid`, `residual sugar`, `chlorides`, `free sulfur dioxide`, `total sulfur dioxide`, `density`, `pH`, `sulphates`, `alcohol`.

The app can accept the UCI dataset including its original `quality` column; it ignores that column when predicting.

## Limitations
This is an educational model trained on the UCI red-wine dataset. Its predictions are estimates based on the dataset and should not replace laboratory testing or expert sensory evaluation. Results may vary with different train/test splits and data distributions.
